pyrebase_config = {
    "apiKey": "AIzaSyCkKmUBwKrQ1_dHm1MPRAvjLQhxhXm-rKk",
    "authDomain": "peach-therapy.firebaseapp.com",
    "databaseURL": "https://peach-therapy-default-rtdb.firebaseio.com",
    "projectId": "peach-therapy",
    "storageBucket": "peach-therapy.appspot.com",
    "messagingSenderId": "339324382594",
    "appId": "1:339324382594:web:8914cf0bc28d695d64f39b"
}

firebase_init = {'databaseURL': 'https://peach-therapy-default-rtdb.firebaseio.com/',
                                     'storageBucket': 'peach_therapy_data'}